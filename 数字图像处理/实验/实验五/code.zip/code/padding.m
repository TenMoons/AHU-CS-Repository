function newimg = padding(img,dx,dy)
[n,m] = size(img);
newimg = zeros(n+dx*2,m+dy*2,class(img));
for i = 1:dx
    newimg(i,dy + 1:dy + m) = img(1,1:m);
end
for i = dx + n + 1:dx*2 + n
    newimg(i,dy + 1:dy + m) = img(n,1:m);
end
for j = 1:dy
    newimg(dx+1:dx+n,j) = img(1:n,1);
end
for j = m + dy + 1:m+dy*2
    newimg(dx+1:dx+n,j) = img(1:n,m);
end

newimg(dx+1:dx+n,dy+1:dy+m) = img;     %扩展
function newimg = AverageFiltering(img,sz)
kernal = ones(sz,sz) ./ (sz * sz);
newimg = convolute(img,kernal);
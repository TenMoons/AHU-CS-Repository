function newimg = depadding(img,dx,dy)
[n,m] = size(img);
newimg = img(dx+1:n-dx,dy+1:m-dy);
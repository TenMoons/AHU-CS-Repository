function newimg = Alpahtrimmed(img,sz,d)
kn = sz;
km = sz;
dx = floor(kn / 2);
dy = floor(km / 2);
[n,m] = size(img);
newimg = img;
%disp(img);
for i = 1:n
    if(i - dx < 1 || i + dx > n)
        continue;
    end
    for j = 1: m
       if(j - dy < 1 || j + dy>m)
           continue;
       end
       tmp = img(i-dx:i+dx,j-dy:j+dy);
       tmp2 = sort(tmp(:));
       res = mean(tmp2(d / 2 + 1: kn * km - d / 2),"all");
       newimg(i,j) = res;
    end
end

end


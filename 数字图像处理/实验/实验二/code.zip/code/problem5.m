close all

clc
clear 
oridpi = 1250;
expdpi = 625;

filepath = "../images/Fig0219(rose1024).tif";
filepath2 = "../images/problem5";

img = imread(filepath);
[n,m] = size(img);

newimg = bilinearInterpolation(img,1250,100);
newimg2 = bilinearInterpolation(newimg,100,1250);
figure
% imshow(newimg);
% imwrite(newimg,filepath2 + "1.bmp");
% 
% figure
% imshow(newimg2);
% imwrite(newimg2,filepath2 + "2.bmp");

[n1,m1] = size(newimg);
smallimgs = zeros(n1,m1,2);
smallimgs(:,:,1) = newimg;
[n2,m2] = size(newimg2);
bigimgs = zeros(n2,m2,2);
bigimgs(:,:,1) = newimg2;





newimg = imresize(img,0.08,"bilinear");
newimg2 = imresize(newimg,12.5,"bilinear");

figure
imshow(newimg);
% smallimgs(:,:,1) = ;
bigimgs(:,:,1) = newimg2;
% imwrite(newimg,filepath2 + "12.bmp");
% figure
% imshow(newimg2);
% imwrite(newimg2,filepath2 + "22.bmp");

imshow(splice(1,2,10,smallimgs));
imshow(splice(1,2,10,bigimgs));
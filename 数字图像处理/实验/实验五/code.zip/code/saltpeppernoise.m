function noisedimg = saltpeppernoise(img,pa,pb)
[n,m] = size(img);
flag = 0;
if(class(img) == "uint8")
    img = double(img) ./ 256;
    flag = 1;
end
x = rand(n,m);
noisedimg = img;
noisedimg(x <= pa) = 0;
noisedimg(x >= 1 - pb) = 1;
if(flag == 1)
    noisedimg = uint8(floor(noisedimg .* 256));
end


clear
clc
close all
filepath = "../images/Fig0219(rose1024).tif";
filepath2 = "../images/rose";
img = imread(filepath);
img2 = ZoomAndShrinking(img,0,16);
imshow(img2);
imwrite(img2,filepath2 + 1 + ".bmp");
img3 = ZoomAndShrinking(img2,1,16);

imshow(img3);
imwrite(img3,filepath2 + 2 + ".bmp");
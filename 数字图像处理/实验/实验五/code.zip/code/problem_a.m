close all
clc
clear
filepath = "../images/"
I = imread(filepath + "ckt-board-orig.tif");
if(class(I) == "uint8")
    I = double(I) ./ 256;
    flag = 1;
end

noise3 = imnoise(I,"salt & pepper",0.4);
imshow(noise3)
sizes = [0,4,8,12,16,20];
[n,m] = size(noise3);
imgs = zeros(n,m,6);
imgs(:,:,1) = noise3;
for i =1:6
    imgs(:,:,i) = Alpahtrimmed(noise3,5,sizes(i));
end
t = splice(2,3,10,imgs);
imshow(t)
imwrite(t,"./problem_a.jpg")
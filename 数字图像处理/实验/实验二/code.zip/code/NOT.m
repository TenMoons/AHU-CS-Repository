function newimg = NOT(img,bitNum)

[n,m] = size(img);
%newimg = zeros(n,m,"uint8");
tmp = pow2(bitNum) - 1;


newimg = tmp - img;
% for i = 1:n
%     for j = 1:m
%         x = img(i,j);
%         nowx = 0;
%         weight = 1;
%         for s=1:8
%             tmp = mod(x,2);
%             if(tmp == 0)
%                 nowx = nowx + weight;
%             end
%             x = fix(x / 2);
%             weight = weight * 2;
%         end
%         newimg(i,j) = nowx;
%     end
% end


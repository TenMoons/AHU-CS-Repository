close all
clc 
clear
filepath = "../images/";
img = imread("../images/Fig_test_pattern_blurring_orig.tif");
imshow(img);
list = [1,3,5,9,15,35];
[n,m] = size(img);
newimgs = zeros(n,m,size(list,2));

for i = 1:size(list,2)
    %tmpimg = padding_0(img,floor(list(i)/2),floor(list(i)/2));
    figure
    newimg = AvarageFiltering(img,list(i));
    %disp(newimg);
    imshow(newimg);
    ti = (i-1) / 2;
    tj = mod(i-1,2);
    %newimg = depadding(newimg,floor(list(i)/2),floor(list(i)/2));
    newimgs(:,:,i) = newimg;
    imwrite(newimg,filepath + "problem1_" + i + ".jpg")
end

%a = 1;
%b = [1,2,3;4,5,6;7,8,9];

%convolute(a,b)

imwrite(splice(3,2,10,newimgs),filepath + "problem1.jpg");
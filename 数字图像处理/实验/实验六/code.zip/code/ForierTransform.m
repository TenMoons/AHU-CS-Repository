function F = ForierTransform(img)
    [M,N] = size(img);
    P = 2*M;
    Q = 2*N;
    img_f = zeros(P, Q);
   
    img_fp = zeros(P, Q);
    img_fp(1:M, 1:N) = img(1:M, 1:N);               %补0
    for x = 1:P
        for y = 1:Q
            img_f(x, y) = img_fp(x, y) .* (-1)^(x+y);           %乘(-1)^{x+y}
        end
    end
    F = fft2(img_f);                %频移后的傅里叶变换图像
end


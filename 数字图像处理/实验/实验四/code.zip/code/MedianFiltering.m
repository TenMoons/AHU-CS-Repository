function newimg = MedianFiltering(img,sz)

dx = floor(sz / 2);
dy = floor(sz / 2);

[n,m] = size(img);
newimg = img;
for i = 1:n
    if(i - dx < 1 || i + dx > n)
        continue;
    end
    for j = 1: m
       if(j - dy < 1 || j + dy>m)
           continue;
       end
       tong = ones(sz*sz,1);
       for k1 = i-dx:i+dx
        for k2 = j-dy:j+dy
            tong((k1-i+dx)*sz + (k2-j+dy+1)) = img(k1,k2);
        end
       end
        tong = sort(tong);
        %disp(tong);
        newimg(i,j) = tong(floor((sz*sz+1) / 2));
    end
end
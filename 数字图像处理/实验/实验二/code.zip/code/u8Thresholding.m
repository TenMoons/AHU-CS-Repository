function newimg = u8Thresholding(img,bit)
count = pow2(bit);
ev = fix(256 / (count - 1));
thres = zeros(1,count + 1);
for i = 1:count-1
    thres(i) = fix((2*i - 1)*ev*0.5);
end
thres(count) = 256;
[n,m] = size(img);
newimg = zeros(n,m,"uint8");

for i = 1:n
    for j = 1:m
        newimg(i,j) = 255;
        for k=1:count-1
            if img(i,j) <= thres(k)
                newimg(i,j) = ev*(k-1);
                break;
            end
        end
    end
end

clc
close all
clear
disp("第三次实验");
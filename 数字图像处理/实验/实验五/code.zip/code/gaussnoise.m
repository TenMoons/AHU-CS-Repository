function noisedimg = gaussnoise(img,mu,sigma)
[n,m] = size(img);
flag = 0;

noisedimg = img + (sqrt(sigma) * randn(n,m) + mu);
noisedimg = max(0,min(noisedimg,1));

function newimg = ZoomAndShrinking(img,a,factor)

[n,m] = size(img);
if a == 0
    newn = fix(n / factor);
    newm = fix(m / factor);
    newimg = zeros(newn,newm,"uint8");
    for i = 1:newn
        for j = 1:newm
            tot = 0;
            for k1 = 1:factor
                for k2 = 1:factor
                    tot = max(tot,img((i-1)*factor + k1,(j-1)*factor + k2));
                end
            end
            tot = fix(tot);
            newimg(i,j) = tot;
        end
    end
elseif a == 1
    newn = n * factor;
    newm = m * factor;
    newimg = zeros(newn,newm,"uint8");
    for i = 1:newn
        for j = 1:newm
            newimg(i,j) = img(fix((i-1) / factor) + 1,fix((j-1) / factor) + 1);
        end
    end
end

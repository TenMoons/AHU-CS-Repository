close all
clc
clear

filepath = "../images/";

img = imread(filepath + "top_ left_flower.tif");
[n,m,z] = size(img);
if(class(img) == "uint8")
    img = double(img) ./ 256;
end
figure
imshow(img);
greyimg = zeros(n,m);
figure 

propotion = [    0.2830    0.1216    0.5954];
for i = 1:n
    for j = 1:m
        s = 0;
        for r = 1:z
            s = s + propotion(r) * img(i,j,r);
        end
        greyimg(i,j) = s;
    end
end
imshow(greyimg)
imgs = zeros(n,m,10);
for k=1:10
    propotion = rand(1,3);
    propotion = propotion ./ sum(propotion);
    for i = 1:n
        for j = 1:m
            s = 0;
            for r = 1:z
                s = s + propotion(r) * img(i,j,r);
            end
            greyimg(i,j) = s;
        end
    end
    imwrite(greyimg,filepath + "problem4_" + k + ".jpg");
    % save("propotion_" + k,propotion);
    imgs(:,:,k)= greyimg;
    disp(propotion);
end
figure
T = splice(5,2,10,imgs);
imshow(T);
imwrite(T,filepath + "problem4_ans.jpg");
% imgs = zeros(n,m,2);
% imgs(:,:,1) = img;
% t = splice(1,3,10,imgs);
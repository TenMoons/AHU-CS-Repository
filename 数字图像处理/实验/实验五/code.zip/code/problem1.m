close all
clc
clear
filepath = "../images/"
I = imread(filepath + "ckt-board-orig.tif");
if(class(I) == "uint8")
    I = double(I) ./ 256;
    flag = 1;
end
[n,m] = size(I);
noise2=imnoise(I, 'gaussian', 0.1, 0.1);%高斯噪声 方差0.01
noise2 = saltpeppernoise(I,0.1,0.1);
% noise2 = gaussnoise(I,0,1);
noise3 = imnoise(I,"salt & pepper",0.2);
a = normrnd(0,1,100,100);
imgs = zeros(n,m,3);
figure
imshow(I);
figure
imshow(noise2);
figure
imshow(noise3);
imgs(:,:,1) = I;
imgs(:,:,2) = noise2;
imgs(:,:,3) = noise3;

imwrite(splice(1,3,10,imgs),filepath + "problem1_peppersalt.jpg");
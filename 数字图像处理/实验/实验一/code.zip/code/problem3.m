path = "../images/";


imgname = "Fig_blurry_moon.tif";
img = imread(path + imgname);
avg = averageIntensity(img)

for i = 1:28
    %figure
    delta = (i - 6) * 10; 
    img2 = thresholdImage(img,avg + delta);
    % disp(avg + delta);
    %subplot(3,3,i)
    %imshow(img2);
    imwrite(img2,path + "/Fig_blurry_moon/" + i + ".jpg");
end

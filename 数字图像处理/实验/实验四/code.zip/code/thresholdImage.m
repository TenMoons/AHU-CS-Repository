function newimg = thresholdImage(img,threshold)

[n,m] = size(img);
newimg = zeros(n,m,class(img));

for i =1:n
    for j = 1:m
        if(img(i,j) >= threshold)  
            if(class(img) == "uint8")
                newimg(i,j) = 255; 
            else
                newimg(i,j) = 1;
            end
    
        end
    end
end
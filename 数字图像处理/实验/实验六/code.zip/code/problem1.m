close all
clc 
clear 

img = imread("../imgs/Fig_characters_test_pattern.tif");
img = double(img) ./ 256;
% % figure
% % imshow(img);
% % figure 
% % imshow(ForierITransform(ForierTransform(img)))
% sizes = [5,15,30,80,230];
% [n,m] = size(img);
% imgs = zeros(n,m,6);
% for i = 1:size(sizes,2)
%     figure
%     imshow(GaussianFiltering(img,n,m,sizes(i)));
%     imgs(:,:,i) = GaussianFiltering(img,n,m,sizes(i));
% end
% imgs(:,:,6) = img;
% imshow(splice(2,3,10,imgs));
% imwrite(splice(2,3,10,imgs),"../imgs/problem1.jpg");
% 
% img2 = ForierTransform(img);
% imshow(img2)
img2 = fft(img);
img3 = ifft(img2);
imshow(img2)


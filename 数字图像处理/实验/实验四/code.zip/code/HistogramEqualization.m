function newimg = HistogramEqualization(img)
    %HISTOGRAMEQUALIZATION 对图像进行直方图均衡
    [n,m] = size(img);
    newimg = zeros(n,m,"uint8");
    his = Histogram(img);       %得到直方图(非归一化)
    totsum = n * m;
    nowsum = 0;
    for i=0:255
        nowsum = nowsum + his(i+1);
        Hp = round(255 * nowsum / totsum);  %映射后的像素灰阶
        newimg(find(img == i)) = Hp;
    end

end


close all
clc
clear


path = "../images/";
img = imread(path + "Fig_fractured_spine.tif");
img = double(img + 5) ./ 256;
%imshow(img);
[n,m] = size(img);
% imgs = zeros(n,m,12);
% 
% 
% for i = 1:4
%     c = 0.5 + i*0.25;
%     for j = 1:3
%         gama = 1.2 - j*0.3;
%         img2 = ((c .* img) .^ gama);
%         %text((i-1)*100,j*100,"hi");
% 
%         imgs(:,:,(i-1)*3 + j) = img2;
%         imshow(img2);
%     end
% end
% figure
% imshow(splice(4,3,10,imgs));
% imwrite(splice(4,3,10,imgs),"./problem2.jpg")
% title('\gama = 0.3时改变c');


imgs = zeros(n,m,10);
for i = 1:10
    c = 0.1 + 0.01*i;
    gama = 0.4;
    img2 = c * ((img) .^ gama);
    img2 = img2 / max(img2,[],"all");
    %text(0,0,"hi");
    imshow(img2);
    imwrite(img2,path + "/Fig_fractured_spine/" + i + ".jpg");
    imgs(:,:,i) = img2;
end
figure
imshow(splice(2,5,10,imgs));
imwrite(splice(2,5,10,imgs),"./problem22.jpg")

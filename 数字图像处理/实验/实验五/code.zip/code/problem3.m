close all
clc
clear

filepath = "../images/";

img = imread(filepath + "ckt-board-orig.tif");
[n,m] = size(img);
if(class(img) == "uint8")
    img = double(img) ./ 256;
end
img = padding(img,3,3);
imgs = zeros(n,m,3);
noisedimg = saltpeppernoise(img,0.25,0.25);

restored1 = MedianFiltering(noisedimg,7);

restored2 = AdaptiveMedian(noisedimg,100);

imgs(:,:,1) = depadding(noisedimg,3,3);
imgs(:,:,2) = depadding(restored1,3,3);
imgs(:,:,3) = depadding(restored2,3,3);

t = splice(1,3,10,imgs);
imshow(t);
for i = 1:size(imgs,3)
    imwrite(imgs(:,:,i),filepath + "problem3_" + i + ".jpg");
end
imwrite(t,filepath + "problem3_ans.jpg");
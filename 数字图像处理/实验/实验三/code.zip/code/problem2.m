clc
close all
clear
% imgs = ["darkPollen","lowContrastPollen","pollen","lightPollen"];
img = imread("C:\Users\20595\Desktop\pic.jpg");
[n,m,z] = size(img);
img2 = zeros(n,m,z,"uint8");
img = double(img) ./ 256;
for i=1:3
    img2(:,:,i) = HistogramEqualization(img(:,:,i));
    disp(img2(:,:,i));
end

imshow(img2);
%img_dark = imread("./images/darkPollen.jpg");
%img = ones(5,5) * 255;
%his = Histogram(img_dark);
%bar(his);

% newimg = HistogramEqualization(img_dark);
% imshow(newimg);
% 
% img = imread("./images/lowContrastPollen.jpg");
% newimg = HistogramEqualization(img);
% imshow(newimg);
% 
% t = tiledlayout(size(imgs,2),2,'TileSpacing','Compact','Padding','Compact');
% 
% for i=1:size(imgs,2)
%     img = imread("./images/" + imgs(i) + ".jpg");
%     nexttile
%     imshow(img);
%     %t.Children((i-1)*2 + 1).Position = [0.1,0.2*i,1,1];
% 
% 
%     newimg = HistogramEqualization(img);
%     nexttile
%     imshow(newimg);
%     imwrite(newimg,"./images/" + imgs(i) + "_2.jpg")
%     %t.Children((i-1)*2 + 1).Position = [0.5,0.2*i,1,1];
% 
% end
% 
% 
% for i=1:size(imgs,2)
%     img = imread("./images/" + imgs(i) + ".jpg");
% 
%     newimg = HistogramEqualization(img);
%     his = Histogram(newimg);
%     figure
%     %subplot(1,4,i);
%     bar(his);
%     %saveas(i,"./images/" + imgs(i) + "_his2.jpg")
% end

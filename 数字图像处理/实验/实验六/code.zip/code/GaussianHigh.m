function new_img = GaussianHigh(img,M,N,D)
    [m,n] = size(img);
    P = 2*m;
    Q = 2*n;
    H = zeros(P,Q);
    for i = 1:P
        for j = 1:Q
            H(i,j) = 1 - exp(-((i - P / 2)^2 + (j - Q / 2)^2) / (2 *D * D));
        end
    end
    timg = imresize(img,[M,N]);
    F = ForierTransform(timg);
    G = F .* H;
    new_img = ForierITransform(G);
end


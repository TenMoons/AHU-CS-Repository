close all
clc
clear 

filepath = "../images/";
img = imread(filepath + "embedded_square_noisy.tif");
newimg2 = HistogramEqualization(img);
mask1 = [0,-1,0;-1,5,-1;0,-1,0];
mask2 = [-1,-1,-1;-1,9,-1;-1,-1,-1];
img = convolute(img,mask2);
img = uint8(img.*256);
%img = thresholdImage(img,1);
img = MedianFiltering(img,5);
figure
imshow(img);
dx = 17;
dy = 17;
img = padding_0(img,dx,dy);
[n,m] = size(img);
newimg1 = img;
for i=1:1:n
    if(i - dx < 1 || i + dx > n)
        i = i - 2*dx;
        continue;
    end
    for j =1:1:m
        if(j - dy < 1 || j + dy > m)
            j = j - 2*dy;
            continue;
        end
        tmp = HistogramEqualization(img(i-dx:i+dx,j-dy:j+dy));
        newimg1(i,j) = tmp(dx+1,dy+1);
    end
end
newimg1 = depadding(newimg1,dx,dy);
figure 
imshow(newimg1);
% newimg1 = uint8((double(newimg1) ./ 256).^0.75 .* 256);
% figure
% imgs = thresholdImage(newimg1,245);
% imshow(imgs);
% figure
% imshow(MedianFiltering(imgs,3));
% newimgs = zeros(n,m,2);
% newimgs(:,:,1) = newimg1;
% newimgs(:,:,2) = newimg2;
% imshow(newimg1);
% imwrite(newimg1,filepath +"problem2_1.jpg");
% imwrite(newimg2,filepath +"problem2_2.jpg");
% im = uint8(splice(1,2,10,newimgs));
% imwrite(im,filepath +"problem2.jpg");
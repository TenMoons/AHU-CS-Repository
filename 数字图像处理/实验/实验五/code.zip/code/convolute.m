function newimg = convolute(img,kernal)
[kn,km] = size(kernal);
dx = floor(kn / 2);
dy = floor(km / 2);

[n,m] = size(img);
newimg = img;
%disp(img);
for i = 1:n
    if(i - dx < 1 || i + dx > n)
        continue;
    end
    for j = 1: m
       if(j - dy < 1 || j + dy>m)
           continue;
       end
       tmp = img(i-dx:i+dx,j-dy:j+dy);
       res = sum(tmp .* kernal,"all");
       newimg(i,j) = res;
    end
end
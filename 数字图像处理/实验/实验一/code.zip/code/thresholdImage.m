function newimg = thresholdImage(img,threshold)

[n,m] = size(img);
newimg = zeros(n,m);

for i =1:n
    for j = 1:m
        if(img(i,j) >= threshold)   
            newimg(i,j) = 1;    
        end
    end
end
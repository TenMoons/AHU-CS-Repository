function img_o = ForierITransform(F)
    img_g = real(ifft2(F));
    [P,Q] = size(img_g);
    M = floor(P / 2);
    N = floor(Q / 2);
    for x = 1:P
        for y = 1:Q
            img_g(x, y) = img_g(x, y) .* (-1)^(x+y);
        end
    end
    img_o = img_g(1:M, 1:N);
end


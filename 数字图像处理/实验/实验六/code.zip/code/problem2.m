close all
clc 
clear
img = imread("../imgs/Fig_characters_test_pattern.tif");
img = double(img) ./ 256;

sizes = [5,15,30,80,230];
[n,m] = size(img);
imgs2 = zeros(n,m,10);
for i = 1:size(sizes,2)
    imgs = zeros(n,m,2);
    subplot(5,1,i)
    imgs(:,:,1) = IdealLowpass(img,sizes(i));
    imgs(:,:,2) = Butterworth(img,2,sizes(i));
    imgs2(:,:,(i-1) * 2 + 1) = imgs(:,:,1);
    imgs2(:,:,(i-1) * 2 + 2) = imgs(:,:,2);
    imshow(splice(1,2,10,imgs)); 
end
figure
imshow(splice(5,2,10,imgs2));
imwrite(splice(5,2,10,imgs2),"../imgs/problem2.jpg")
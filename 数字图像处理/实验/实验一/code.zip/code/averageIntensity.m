function  avgintensity = averageIntensity(img)

[n,m] = size(img);
%disp(sum(img,'all'));
avgintensity = sum(double(img),'all') / (n * m);
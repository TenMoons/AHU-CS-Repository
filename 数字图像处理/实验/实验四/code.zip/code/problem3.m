close all
clc
clear

filepath = "../images/";
img = imread(filepath + "problem2_local.jpg");
[n,m] = size(img);

newimgs = zeros(n,m,3,"uint8");
%newimg1 = uint8((double(img) ./ 256) .^ 0.6 .* 256);
newimg1 = MedianFiltering(img,3);

newimg2 = uint8(AverageFiltering(img,3) .* 256);
figure 
%newimg1 = thresholdImage(newimg1,200);

%newimg1 = thresholdImage(newimg1,200);
% newimg1 = uint8(AverageFiltering(newimg1,3) .* 256);
imshow(newimg1);
% figure
% imshow(newimg2);
%imwrite(newimg1,filepath + "problem3_1.jpg");
%imwrite(newimg2,filepath + "problem3_2.jpg");
% newimgs(:,:,1) = img;
% newimgs(:,:,2) = newimg1;
% newimgs(:,:,3) = newimg2;
% imwrite(splice(1,3,10,newimgs),filepath + "problem3.jpg");
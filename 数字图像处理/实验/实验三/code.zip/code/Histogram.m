function histogram = Histogram(img)
%HISTOGRAM 返回图像直方图
%   参数 img: 图像


[n,m] = size(img);

tong = zeros(256,1,"uint32");

for i = 1:n
    for j= 1:m
        if(img(i,j) < 256)
            tong(img(i,j) + 1,1) = tong(img(i,j) + 1,1) + 1;
        end
    end
end

histogram = tong;

end


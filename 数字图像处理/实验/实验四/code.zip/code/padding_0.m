function newimg = padding_0(img,dx,dy)
[n,m] = size(img);
newimg = zeros(n+dx*2,m+dy*2,class(img));
newimg(dx+1:dx+n,dy+1:dy+m) = img;     %扩展
close all
clear

path = "../images/";
img = imread(path + "Fig_DFT_no_log.tif");
img = double(img);
%imshow(img);
[n,m] = size(img);
% img = img + 1;
% for i =1:n
%     for j = 1:m
%         if(img(i,j) >= 0.5)
%             img(i,j) = img(i,j) + 1;
%         else
%             img(i,j) = img(i,j) + 1.6;
%         end
%     end
% end

c = 255 / log(1 + max(img,[],"all"))
[n,m] = size(img);
imgs = zeros(n,m,10,"uint8");
img = img + 1.0;
%c = input("");
figure;
for k = 1:10
    % c = k*10;
    %c = k*5 + 50;
    img2 = c * log(img);
    img2 = floor(img2);
    img2 = uint8(img2);
    % img2 = img2 .^ 2;
    %plot(img);
    subplot(2,5,k);
    imshow(img2);
    imwrite(img2,path + "Fig_DFT_no_log/" + k + ".jpg");
    imgs(:,:,k) = img2;
end
figure
imshow(splice(2,5,10,imgs));
imwrite(splice(2,5,10,imgs),"./problem1.jpg")
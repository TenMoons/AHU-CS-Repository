function newimg = myflip(img,flag)

[n,m] = size(img);
newimg = zeros(n,m);

if flag == 1
   tmp = zeros(n,n);
   for i=1:n
        tmp(i,n + 1 - i) = 1;
   end
   newimg = tmp * img;
elseif flag == 0
   tmp = zeros(m,m);
   for i=1:m
        tmp(i,m + 1 - i) = 1;
   end
   newimg = img * tmp;
end


function newimg = AdaptiveMedian(img,maxsz)


[n,m] = size(img);
newimg = img;
for i = 1:n
    for j = 1: m
        dx = 0;
        dy = 0;
        smin = 0;smax = 0;smd = 0;
        while(1)
            if(i - dx < 1 || i + dx > n || j - dy < 1 || j + dy>m)
                break;
            end
            if(dx > maxsz)
                break;
            end
            tmp = img(i - dx:i+dx,j-dy:j+dy);
            smax = max(tmp(:));
            smin = min(tmp(:));
            smd = median(tmp(:));
            if(smax - smd > 0 && smin - smd < 0)
                if(smax - img(i,j) > 0 && smin - img(i,j) < 0)
                    newimg(i,j) = img(i,j);
                else
                    newimg(i,j) = smd;
                end
                break;
            end
            dx = dx + 1;
            dy = dy + 1;
        end
    end
end
function bigimg = splice(height,width,whitewidth,imgs)

[n,m] = size(imgs(:,:,1));
realn = (n+whitewidth);
realm = (m+whitewidth);
bigimg = zeros((n+whitewidth)*height - whitewidth,(m+whitewidth)*width-whitewidth,class(imgs(:,:,1)));
if(height*width ~= size(imgs,3))
    disp("输入图像数量和拼接模板不符");
    return;
end

for i = 1:height
    for j = 1:width
        bigimg((i-1)*realn+1:(i-1)*realn+n,(j-1)*realm+1:(j-1)*realm+m) = imgs(:,:,(i-1)*width + j);
    end
end

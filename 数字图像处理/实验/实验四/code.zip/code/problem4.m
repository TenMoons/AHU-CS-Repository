close all
clc
clear 

filepath = "../images/";
img = imread(filepath + "Fig_blurry_moon.tif");
mask0 = 1;
mask1 = [0,-1,0;-1,4,-1;0,-1,0];
mask2 = [-1,-1,-1;-1,8,-1;-1,-1,-1];

[n,m] = size(img);
newimgs = zeros(n,m,3);
newimgs(:,:,1) = convolute(img,mask0);
newimgs(:,:,2) = convolute(img,mask1);
newimgs(:,:,3) = convolute(img,mask2);

figure
imshow(newimgs(:,:,2));
figure
imshow(newimgs(:,:,3));

%imshow(splice(1,3,10,newimgs));
%imwrite(newimgs(:,:,2),filepath +"problem4_1.jpg");
%imwrite(newimgs(:,:,3),filepath +"problem4_2.jpg");
%imwrite(splice(1,3,10,newimgs),filepath +"problem4.jpg");
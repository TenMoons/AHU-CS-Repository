
close all
clc
clear
filepath = "../images/Fig0221(a)(ctskull-256).tif";
filepath2 = "../images/Fig0221(a)(ctskull-256)";
img = imread(filepath);
[n,m] = size(img);
imgs = zeros(n,m,8,"uint8");
for i = 1:8
    newimg = u8Thresholding(img,9 - i);
    % subplot(2,4,i);
    imgs(:,:,9 - i) = newimg;
    % imshow(newimg)
    imwrite(newimg,filepath2 + "_" + (9-i) + "bit.bmp");
end

img_n = splice(2,4,10,imgs);
imshow(img_n);
imwrite(img_n,filepath2 + "ans.bmp")
function new_img = GaussianFiltering(img,M,N,D)
    [m,n] = size(img);
    P = 2*M;
    Q = 2*N;
    H = zeros(P,Q);
    for i = 1:P
        for j = 1:Q
            H(i,j) = exp(-((i - P / 2)^2 + (j - Q / 2) ^ 2) / (2*D*D));         % 
        end
    end
    timg = imresize(img,[M,N]);
    F = ForierTransform(timg);
    G = F .* H;
    new_img = ForierITransform(G);
end


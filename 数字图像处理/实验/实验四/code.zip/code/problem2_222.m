close all
clc
clear 

filepath = "../images/";
img = imread(filepath + "embedded_square_noisy.tif");
img = img(:,:,1);
newimg2 = HistogramEqualization(img);
% mask1 = [0,-1,0;-1,5,-1;0,-1,0];
mask2 = [-1,-1,-1;-1,9,-1;-1,-1,-1];
% img = convolute(img,mask2);
img = uint8(img.*256);
img = thresholdImage(img,20);
[n,m] = size(img);
newimgs = zeros(n,m,2,"uint8");
img = MedianFiltering(img,5);
newimgs(:,:,1) = img;
imwrite(img,filepath + "problem2_threshold.jpg");

img = MedianFiltering(img,5);
newimgs(:,:,2) = img;
imwrite(img,filepath + "problem2_threshold+Median.jpg");


figure
imshow(img);
% dx = 1;
% dy = 1;
% img = padding_0(img,dx,dy);
% [n,m] = size(img);
% newimg1 = img;
% for i=1:2*dx+1:n
%     if(i - dx < 1 || i + dx > n)
%         i = i - 2*dx;
%         continue;
%     end
%     for j =1:2*dy+1:m
%         if(j - dy < 1 || j + dy > m)
%             j = j - 2*dy;
%             continue;
%         end
%         %disp(HistogramEqualization(img(i-dx:i+dx,j-dy:j+dy)));
%         newimg1(i-dx:i+dx,j-dy:j+dy) = HistogramEqualization(img(i-dx:i+dx,j-dy:j+dy));
%         %disp(string(i) + " " + string(j));
%     end
% end
% newimg1 = depadding(newimg1,dx,dy);
% img = depadding(img,dx,dy);
% newimgs = zeros(n-dx*2,m - dy* 2,2,"uint8");
% newimgs(:,:,1) = img;
% newimgs(:,:,2) = newimg2;
%newimgs(:,:,3) = newimg2;
% figure 
% imshow(newimg1);
% imwrite(newimg1,filepath + "problem2_local.jpg");
% figure
% imshow(newimg2);
% imwrite(newimg2,filepath + "problem2_global.jpg");

imwrite(splice(1,2,10,newimgs),filepath + "problem2_2Median.jpg");
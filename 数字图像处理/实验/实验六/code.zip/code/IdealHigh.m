function new_img = IdealHigh(img,D0)
    [M,N] = size(img);
    P = 2*M;
    Q = 2*N;
    H = zeros(P,Q);
    for i = 1:P
        for j=1:Q
            dis = sqrt((i - P / 2) ^ 2 + (j - Q / 2) ^ 2);
            if(dis > D0)
                H(i,j) = 1;
            else
                H(i,j) = 0;
            end
            
        end
    end
    F = ForierTransform(img);
    G = F .* H;
    new_img = ForierITransform(G);
n = 512;
m = 512;
centerx = n / 2 + 1;
centery = m / 2 + 1;
w = 40;
h = 20;
myimage = zeros(n,m);
myimage(centerx - h / 2:centerx + h / 2 - 1,centery - w / 2:centery + w / 2 - 1) = 255;
imshow(myimage);

filepath = "../images/problem1";

imwrite(myimage,filepath + ".bmp");

% 
% filepath = "../images/problem1";
% I = imread(filepath + ".bmp","bmp");
% imwrite(I,filepath + ".tif");
% imwrite(I,filepath + ".jpg");

function new_img = Butterworth(img,order,D0)
    [M,N] = size(img);
    P = 2*M;
    Q = 2*N;
    H = zeros(P,Q);
    for i = 1:P
        for j=1:Q
            dis = sqrt((i - P / 2) ^ 2 + (j - Q / 2) ^ 2);
            H(i,j) = 1 / (1 + (dis / D0) ^ 2*order);
        end
    end
    F = ForierTransform(img);
    G = F .* H;
    new_img = ForierITransform(G);
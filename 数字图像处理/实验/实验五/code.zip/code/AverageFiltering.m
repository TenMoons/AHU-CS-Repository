function newimg = AverageFiltering(img,sz,method,varargin)
flag = 0;
if(class(img) == "uint8")
    img = double(img) ./ 256;
    flag = 1;
end
switch method
    case "Arithmetic"
        kernal = ones(sz,sz) ./ (sz * sz);
        newimg = convolute(img,kernal);
    case "Geometric"
        newimg = GeometricMean(img,sz);
    case "Alpha-trimmed"
        newimg = Alpahtrimmed(img,sz,varargin{1});
    otherwise
        disp("没有该选项！");
        newimg = img;
end

if(flag == 1)
    newimg = uint8(floor(newimg .* 256));
end
filepath = "../images/Fig_blurry_moon.tif";
img = imread(filepath);
newimg = NOT(img,8);
subplot(1,2,1);
imshow(img);
subplot(1,2,2);
imshow(newimg);
imwrite(newimg,"../images/problem2.bmp");
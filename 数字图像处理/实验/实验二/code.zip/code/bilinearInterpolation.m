function newimg = bilinearInterpolation(img,oridpi,expdpi)


% figure
% img2 = imresize(img,2,"bilinear");
% imshow(img2);
% 
% 
% figure
% img2 = imresize(img,0.25,"bilinear");
% imshow(img2);

[n,m] = size(img);
ev = oridpi / expdpi;

newn = fix(n * (expdpi / oridpi));
newm = fix(m * (expdpi / oridpi));
newimg = zeros(newn,newm,"uint8");
for i=1:newn
    for j = 1:newm
        posx = 1 + (i - 1) * ev;
        posy = 1 + (j - 1) * ev;
        lx = fix(posx);
        ly = fix(posy);
        if(lx > n-1)
            disp(lx);
        end
         if(ly > m-1)
            disp(ly);
        end
        lx = min(lx,n-1);
        ly = min(ly,m-1);
        a = img(lx,ly);
        b = img(lx + 1,ly);
        c = img(lx,ly + 1);
        d = img(lx + 1,ly + 1);
        alpha1 = posx - lx;
        alpha2 = posy - ly;
        e = (1 - alpha1) * a + alpha1 * b;
        f = (1 - alpha1) * c + alpha1 * d;
        g = (1 - alpha2) * e + alpha2 * f;
        newimg(i,j) = round(g);
    end
end




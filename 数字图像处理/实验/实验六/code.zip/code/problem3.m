close all
clc 
clear 

img = imread("../imgs/Fig_characters_test_pattern.tif");
img = double(img) ./ 256;

sizes = [15,30,80];
[n,m] = size(img);
imgs2 = zeros(n,m,9);
for i = 1:size(sizes,2)
    imgs = zeros(n,m,3);

    imgs2(:,:,(i-1) * 3 + 1) = IdealHigh(img,sizes(i))+0.5*img ;
    imgs2(:,:,(i-1) * 3 + 2) = GaussianHigh(img,n,m,sizes(i))+0.5*img ;
    imgs2(:,:,(i-1) * 3 + 3) = ButterworthHigh(img,2,sizes(i)) +0.5*img ;
end
imshow(splice(3,3,10,imgs2))
imwrite(splice(3,3,10,imgs2),"../imgs/problem3.jpg")
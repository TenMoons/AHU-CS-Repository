clc
close all
clear

img = imread("./images/Lena.bmp");
img = double(img) ./ 256;

img2 = rand(512,512);

t = tiledlayout(1,3,'TileSpacing','Compact','Padding','Compact');

nexttile
imshow(img);
nexttile
newimg = myflip(img,0);
imshow(newimg);
nexttile
newimg = myflip(img,1);
imshow(newimg);
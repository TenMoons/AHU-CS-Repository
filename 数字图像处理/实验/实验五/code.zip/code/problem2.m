close all
clc
clear

filepath = "../images/";

% noisedimg = saltpeppernoise(img,0.1,0.1);
% 
% % imwrite(noisedimg,filepath + 'problem2_1.jpg');
% restoredimg = MedianFiltering(noisedimg,5);
% % imwrite(restoredimg,filepath + 'problem2_2.jpg');
% imgs = zeros(n,m,2,class(img));
% imgs(:,:,1) = noisedimg;
% imgs(:,:,2) = restoredimg;





% img = imread(filepath + 'problem2_2.jpg');
% %img = padding(img,2,2);
% [n,m] = size(img);
% n = n - 4;
% m = m - 4;
% if(class(img) == "uint8")
%     img = double(img) ./ 256;
% end
% imgs = zeros(n,m,4,class(img));

% noisedimg = imread(filepath + "problem2_noisedz.jpg");
% imshow(noisedimg);
% noisedimg = padding(noisedimg,2,2);
% imwrite(noisedimg,filepath + "problem2_noisedz.jpg");
% restoredimg1 = AverageFiltering(noisedimg,5,"Arithmetic");
% restoredimg2 = AverageFiltering(noisedimg,5,"Geometric");
% restoredimg3 = MedianFiltering(noisedimg,5);
% restoredimg4 = AverageFiltering(noisedimg,5,"Alpha-trimmed",2);
% 
% figure
% imshow(noisedimg);
% 
% imgs(:,:,1) = depadding(restoredimg1,2,2);
% imgs(:,:,2) = depadding(restoredimg2,2,2);
% imgs(:,:,3) = depadding(restoredimg3,2,2);
% imgs(:,:,4) = depadding(restoredimg4,2,2);
% figure
% imshow(splice(2,2,10,imgs));
% 
% imwrite(noisedimg,filepath + "problem2_noised2.jpg");
% for i =1:size(imgs,3)
%     imwrite(imgs(:,:,i),filepath + "problem2_restored_" + i + ".jpg");
% end
% 
% imwrite(splice(2,2,10,imgs),filepath + "problem2_4.jpg");


img1 = imread(filepath + 'problem2_restored_3.jpg');
img2 = imread(filepath + 'problem2_restored_4.jpg');
[n,m] = size(img1);
% imgs = zeros(n,m,2);
% bar1 = Histogram(img1);
% bar2 = Histogram(img2);
% figure
% a = bar(bar1);
% figure
% b = bar(bar2);
% bb = [bar1,bar2];
% figure 
% bar(bb);
if(class(img1) == "uint8")
    img1 = double(img1) ./ 256;
    img2 = double(img2) ./ 256;
end
kernal = [-1,-1,-1;-1,8,-1;-1,-1,-1];
by1 = convolute(img1,kernal);
figure
imshow(convolute(img2,kernal));
by2 = convolute(img2,kernal);
imwrite(by1,filepath + "problem2_by1.jpg");
imwrite(by2,filepath + "problem2_by2.jpg");

imgs(:,:,1) = by1;
imgs(:,:,2) = by2;
imwrite(splice(1,2,10,imgs),filepath + "problem2_5.jpg");



close all
clc 
clear

%problem1();

%problem2();

path = "../images/";
img = imread(path + "Fig_DFT_no_log.tif");
img2 = double(img) ./ 255;

imshow(img2)
close all
clc
clear

filepath = "../images/";

img = imread(filepath + "Fig0630(01)(strawberries_fullcolor).tif");
[n,m,z] = size(img);
if(class(img) == "uint8")
    img = double(img) ./ 256;
end
k = 0.7;

figure
img2 = img * k;
imshow(img2);

CMY = 1 - img;          %转换到CMY空间
CMY = CMY * k;          %CMY空间倍乘
new_img = 1 - CMY;      %转换到RGB空间
figure
imshow(new_img)

new_img = (1 - k) + k*img;

figure
imshow(new_img)

bigims = zeros(n,m*3 + 10 * 2,3);
bigims(1:n,1:m,:) = img;
bigims(1:n,m + 10 + 1:m * 2 + 10,:) = img2;
bigims(1:n,m*2 + 10*2 + 1:m * 3 + 10*2,:) = new_img;
imshow(bigims);
imwrite(img2,filepath + "problem5_1.jpg");
imwrite(bigims,filepath + "problem5_ans.jpg");

